// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

final kWhite = Colors.white;
const kBlack = Colors.black;
const kGrey = Colors.grey;
const kBlue = Colors.blue;
const KBcolor = Colors.deepPurpleAccent;
const Kred = Colors.red;