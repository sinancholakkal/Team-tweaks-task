const double Klheight = 500;
const double Klwidth = 340;
const double KRwidth = 340;
const double KRheight = 950;
const double kmenuRadius = 14;