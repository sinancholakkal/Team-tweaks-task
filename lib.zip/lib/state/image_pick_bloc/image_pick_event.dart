part of 'image_pick_bloc.dart';

@immutable
sealed class ImagePickEvent {}
class ImagePickingEvent extends ImagePickEvent{}
